
export interface User {
  id: string;
  username: string;
  password?: string; // Password stored only during signup, not fetched typically
  friendIds: string[];
  createdAt: string;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
  isAIMessage?: boolean; // To identify messages from Klaus AI
}

export interface Chat {
  id: string; // Typically other user's ID or KLAUS_AI_USER_ID
  name: string;
  type: 'user' | 'ai';
  lastMessage?: Message;
  unreadCount?: number; 
}

// For Gemini chat history
export interface ChatHistoryPart {
  role: "user" | "model";
  parts: { text: string }[];
}
