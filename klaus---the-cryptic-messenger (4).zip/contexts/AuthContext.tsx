
import React, { createContext, useState, useContext, useEffect, useCallback } from 'react';
import { User } from '../types';
import { storageService } from '../services/storageService';
import { authService } from '../services/authService';
import { STORAGE_KEYS } from '../constants';

interface AuthContextType {
  currentUser: User | null;
  isLoadingAuth: boolean;
  login: (username: string, password: string) => Promise<User | null>;
  signup: (username: string, password: string) => Promise<User | null>;
  logout: () => void;
  updateCurrentUserFriends: (friendId: string, action: 'add' | 'remove') => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoadingAuth, setIsLoadingAuth] = useState(true);

  const loadCurrentUser = useCallback(() => {
    setIsLoadingAuth(true);
    const storedUser = storageService.getItem<User>(STORAGE_KEYS.CURRENT_USER);
    if (storedUser) {
      // Re-fetch user from main users list to ensure data consistency (e.g. updated friend list)
      const users = storageService.getItem<User[]>(STORAGE_KEYS.USERS) || [];
      const freshUser = users.find(u => u.id === storedUser.id);
      setCurrentUser(freshUser || null);
    } else {
      setCurrentUser(null);
    }
    setIsLoadingAuth(false);
  }, []);

  useEffect(() => {
    loadCurrentUser();
     // Listen for storage changes from other tabs (basic sync)
    const handleStorageChange = (event: StorageEvent) => {
      if (event.key === STORAGE_KEYS.CURRENT_USER || event.key === STORAGE_KEYS.USERS) {
        loadCurrentUser();
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [loadCurrentUser]);

  const login = async (username: string, password: string): Promise<User | null> => {
    setIsLoadingAuth(true);
    const user = await authService.login(username, password);
    setCurrentUser(user);
    setIsLoadingAuth(false);
    return user;
  };

  const signup = async (username: string, password: string): Promise<User | null> => {
    setIsLoadingAuth(true);
    const user = await authService.signup(username, password);
    setCurrentUser(user);
    setIsLoadingAuth(false);
    return user;
  };

  const logout = () => {
    authService.logout();
    setCurrentUser(null);
  };
  
  const updateCurrentUserFriends = useCallback((friendId: string, action: 'add' | 'remove') => {
    setCurrentUser(prevUser => {
      if (!prevUser) return null;
      const updatedFriendIds = action === 'add'
        ? [...new Set([...prevUser.friendIds, friendId])]
        : prevUser.friendIds.filter(id => id !== friendId);
      const updatedUser = { ...prevUser, friendIds: updatedFriendIds };
      
      // Also update the user in the main users list in localStorage
      const users = storageService.getItem<User[]>(STORAGE_KEYS.USERS) || [];
      const userIndex = users.findIndex(u => u.id === prevUser.id);
      if (userIndex !== -1) {
        users[userIndex] = updatedUser;
        storageService.setItem(STORAGE_KEYS.USERS, users);
      }
      storageService.setItem(STORAGE_KEYS.CURRENT_USER, updatedUser); // Update current user session
      return updatedUser;
    });
  }, []);


  return (
    <AuthContext.Provider value={{ currentUser, isLoadingAuth, login, signup, logout, updateCurrentUserFriends }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
