
import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';
import AuthPage from './components/AuthPage';
import ChatPage from './components/ChatPage';
import LoadingSpinner from './components/LoadingSpinner';

const App: React.FC = () => {
  const { currentUser, isLoadingAuth } = useAuth();

  if (isLoadingAuth) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-klaus-deep-dark">
        <LoadingSpinner message="Awakening Klaus..." />
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/auth" element={!currentUser ? <AuthPage /> : <Navigate to="/chat" />} />
      <Route path="/chat" element={currentUser ? <ChatPage /> : <Navigate to="/auth" />} />
      <Route path="*" element={<Navigate to={currentUser ? "/chat" : "/auth"} />} />
    </Routes>
  );
};

export default App;
