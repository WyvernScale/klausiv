
import { Message, User, Chat } from '../types';
import { storageService } from './storageService';
import { STORAGE_KEYS, KLAUS_AI_USER_ID, KLAUS_AI_USERNAME } from '../constants';
import { userService } from './userService';

const generateId = () => crypto.randomUUID();

export const messageService = {
  async getMessages(userId1: string, userId2: string): Promise<Message[]> {
    const allMessages = storageService.getItem<Message[]>(STORAGE_KEYS.MESSAGES) || [];
    return allMessages
      .filter(msg => 
        (msg.senderId === userId1 && msg.receiverId === userId2) ||
        (msg.senderId === userId2 && msg.receiverId === userId1)
      )
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  },

  async sendMessage(senderId: string, receiverId: string, content: string, isAIMessage: boolean = false): Promise<Message> {
    const newMessage: Message = {
      id: generateId(),
      senderId,
      receiverId,
      content,
      timestamp: new Date().toISOString(),
      isAIMessage,
    };

    const allMessages = storageService.getItem<Message[]>(STORAGE_KEYS.MESSAGES) || [];
    allMessages.push(newMessage);
    storageService.setItem(STORAGE_KEYS.MESSAGES, allMessages);
    return newMessage;
  },

  async getChatList(currentUserId: string): Promise<Chat[]> {
    const users = await userService.getAllUsers(currentUserId);
    const friends = await userService.getFriends(currentUserId);
    const allMessages = storageService.getItem<Message[]>(STORAGE_KEYS.MESSAGES) || [];

    const chatPartners: User[] = [];
    // Collect all unique users who have exchanged messages with the current user
    allMessages.forEach(msg => {
      if (msg.senderId === currentUserId && !chatPartners.some(p => p.id === msg.receiverId) && msg.receiverId !== KLAUS_AI_USER_ID) {
        const partner = users.find(u => u.id === msg.receiverId) || friends.find(f => f.id === msg.receiverId);
        if (partner) chatPartners.push(partner);
      } else if (msg.receiverId === currentUserId && !chatPartners.some(p => p.id === msg.senderId) && msg.senderId !== KLAUS_AI_USER_ID) {
        const partner = users.find(u => u.id === msg.senderId) || friends.find(f => f.id === msg.senderId);
        if (partner) chatPartners.push(partner);
      }
    });
    
    // Add all friends, even if no messages yet
    friends.forEach(friend => {
      if (!chatPartners.some(p => p.id === friend.id)) {
        chatPartners.push(friend);
      }
    });


    const uniqueChatPartners = Array.from(new Set(chatPartners.map(p => p.id)))
      .map(id => chatPartners.find(p => p.id === id)!);


    const chatList: Chat[] = uniqueChatPartners.map(partner => {
      const messagesWithPartner = allMessages.filter(
        msg => (msg.senderId === currentUserId && msg.receiverId === partner.id) ||
               (msg.senderId === partner.id && msg.receiverId === currentUserId)
      ).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      
      return {
        id: partner.id,
        name: partner.username,
        type: 'user',
        lastMessage: messagesWithPartner[0],
        // unreadCount: 0, // Implement unread count if needed
      };
    });

    // Add Klaus AI to chat list
    const klausAiMessages = allMessages.filter(
      msg => (msg.senderId === currentUserId && msg.receiverId === KLAUS_AI_USER_ID) ||
             (msg.senderId === KLAUS_AI_USER_ID && msg.receiverId === currentUserId)
    ).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    chatList.unshift({
      id: KLAUS_AI_USER_ID,
      name: KLAUS_AI_USERNAME,
      type: 'ai',
      lastMessage: klausAiMessages[0],
      // unreadCount: 0,
    });
    
    // Sort chats by last message timestamp
    chatList.sort((a, b) => {
        if (!a.lastMessage && !b.lastMessage) return 0;
        if (!a.lastMessage) return 1;
        if (!b.lastMessage) return -1;
        return new Date(b.lastMessage.timestamp).getTime() - new Date(a.lastMessage.timestamp).getTime();
    });

    return chatList;
  }
};
