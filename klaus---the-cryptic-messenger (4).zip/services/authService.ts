
import { User } from '../types';
import { storageService } from './storageService';
import { STORAGE_KEYS, MIN_PASSWORD_LENGTH } from '../constants';

const generateId = () => crypto.randomUUID();

export const authService = {
  async signup(username: string, password: string): Promise<User | null> {
    if (!username.trim() || !password.trim()) {
      throw new Error("Username and password cannot be empty.");
    }
    if (password.length < MIN_PASSWORD_LENGTH) {
      throw new Error(`Password must be at least ${MIN_PASSWORD_LENGTH} characters long.`);
    }

    const users = storageService.getItem<User[]>(STORAGE_KEYS.USERS) || [];
    if (users.some(user => user.username.toLowerCase() === username.toLowerCase())) {
      throw new Error("Username already exists. Choose another.");
    }

    const newUser: User = {
      id: generateId(),
      username,
      // In a real app, password would be securely hashed here.
      // For this demo, we store it temporarily to simulate login,
      // but it should not be part of the User object returned or stored long-term this way.
      // It's better to handle password comparison without storing it directly on the user object.
      // For simplicity, we'll create a temporary password field that `login` checks.
      // This password will be on the User object stored in `klaus_users`.
      password: password, // Storing plain for demo; DO NOT DO THIS IN PRODUCTION
      friendIds: [],
      createdAt: new Date().toISOString(),
    };

    users.push(newUser);
    storageService.setItem(STORAGE_KEYS.USERS, users);
    storageService.setItem(STORAGE_KEYS.CURRENT_USER, { ...newUser, password: undefined }); // Don't store password in current session object
    return { ...newUser, password: undefined };
  },

  async login(username: string, password: string): Promise<User | null> {
    const users = storageService.getItem<User[]>(STORAGE_KEYS.USERS) || [];
    const user = users.find(u => u.username.toLowerCase() === username.toLowerCase());

    if (!user) {
      throw new Error("User not found. Perhaps you meant to sign up?");
    }
    // In a real app, compare hashed password. Here, direct comparison for demo.
    if (user.password !== password) {
      throw new Error("Incorrect password. The shadows betray your entry.");
    }
    
    const userToStore = { ...user, password: undefined }; // Remove password before storing in session
    storageService.setItem(STORAGE_KEYS.CURRENT_USER, userToStore);
    return userToStore;
  },

  logout(): void {
    storageService.removeItem(STORAGE_KEYS.CURRENT_USER);
  },

  getCurrentUser(): User | null {
    return storageService.getItem<User>(STORAGE_KEYS.CURRENT_USER);
  },
};
