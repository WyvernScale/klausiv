
import { GoogleGenAI, GenerateContentResponse, Chat as GeminiChat } from "@google/genai";
import { KLAUS_AI_SYSTEM_INSTRUCTION, GEMINI_MODEL_NAME } from '../constants';
import { ChatHistoryPart } from "../types";

let ai: GoogleGenAI | null = null;
let klausChat: GeminiChat | null = null;

const initializeGemini = (): GoogleGenAI | null => {
  if (ai) {
    return ai;
  }
  try {
    const apiKey = process.env.API_KEY;
    if (typeof apiKey !== 'string' || !apiKey) {
      console.warn("Gemini API Key is not configured or invalid in the environment. Klaus AI will be impaired as it relies on this key.");
      ai = null; // Ensure ai is null if key is invalid
      return null;
    }
    ai = new GoogleGenAI({ apiKey });
  } catch (error) {
    console.error("Failed to initialize GoogleGenAI. Klaus AI may not function correctly:", error);
    ai = null; // Ensure ai is null if initialization fails
  }
  return ai;
};

const getKlausChat = (): GeminiChat | null => {
  const currentAiInstance = initializeGemini(); 
  if (!currentAiInstance) {
    return null;
  }

  if (!klausChat) {
    try {
        klausChat = currentAiInstance.chats.create({
        model: GEMINI_MODEL_NAME,
        config: {
            systemInstruction: KLAUS_AI_SYSTEM_INSTRUCTION,
        },
        // history: [] // History is managed by passing it in getKlausAIChatResponse if needed or relying on chat instance's memory
        });
    } catch (error) {
        console.error("Failed to create Klaus chat session:", error);
        klausChat = null; // Ensure chat is null if creation fails
    }
  }
  return klausChat;
}

export const geminiService = {
  isConfigured: (): boolean => {
    initializeGemini(); // Attempt to initialize if not already
    return !!ai; // True if 'ai' instance is successfully created
  },

  async getKlausAIChatResponse(prompt: string, chatHistory: ChatHistoryPart[]): Promise<string> {
    const chat = getKlausChat();
    if (!chat) {
      return "Klaus is currently lost in the void (AI interface not initialized or chat session failed).";
    }
    
    // The current @google/genai chat.sendMessage manages history internally from previous calls to itself within the same 'chat' instance.
    // If a fully fresh context per message (ignoring chat instance memory) is desired, 
    // ai.models.generateContent with explicit history should be used, or a new chat instance created.
    // For this implementation, we rely on the chat instance's memory.
    // The passed 'chatHistory' param might be used if we were to reconstruct history for each call,
    // but 'chat.sendMessage' handles this for its own instance.

    try {
      const response: GenerateContentResponse = await chat.sendMessage({ message: prompt });
      return response.text.trim();
    } catch (error) {
      console.error("Error communicating with Klaus (Gemini API):", error);
      let errorMessage = "Klaus's whispers are distorted by static (API error).";
      if (error instanceof Error) {
        // It's better to check error.name or specific error codes if the SDK provides them
        if (error.message.includes('API key not valid') || error.message.includes('PERMISSION_DENIED')) {
             errorMessage = "The runes of power are misaligned (Invalid API Key or Permission Denied). Klaus cannot respond.";
        } else if (error.message.includes('400')) { // Generic bad request
             errorMessage = "Klaus finds your query indecipherable (Bad Request).";
        } else if (error.message.match(/50\d/)) { // Server errors 500, 502, 503, etc.
             errorMessage = "A storm rages in the digital ether (Server Error). Klaus is temporarily unavailable.";
        }
      }
      // Reset chat instance if a critical error occurs, so next attempt starts fresh
      if (errorMessage.includes("Invalid API Key")) {
          klausChat = null; 
          ai = null; // Also reset AI if API key is the issue.
      }
      return errorMessage;
    }
  },
};
