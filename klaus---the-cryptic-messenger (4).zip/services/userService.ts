
import { User } from '../types';
import { storageService } from './storageService';
import { STORAGE_KEYS } from '../constants';

export const userService = {
  async getAllUsers(currentUserId?: string): Promise<User[]> {
    const users = storageService.getItem<User[]>(STORAGE_KEYS.USERS) || [];
    // Exclude current user and don't return passwords
    return users
      .filter(user => user.id !== currentUserId)
      .map(({ password, ...userWithoutPassword }) => userWithoutPassword);
  },

  async getUserById(userId: string): Promise<User | null> {
    const users = storageService.getItem<User[]>(STORAGE_KEYS.USERS) || [];
    const user = users.find(u => u.id === userId);
    if (user) {
      const { password, ...userWithoutPassword } = user;
      return userWithoutPassword;
    }
    return null;
  },

  async addFriend(currentUserId: string, friendIdToAdd: string): Promise<boolean> {
    if (currentUserId === friendIdToAdd) return false; // Cannot add self

    const users = storageService.getItem<User[]>(STORAGE_KEYS.USERS) || [];
    const currentUserIndex = users.findIndex(u => u.id === currentUserId);
    const friendUserIndex = users.findIndex(u => u.id === friendIdToAdd);

    if (currentUserIndex === -1 || friendUserIndex === -1) return false; // User not found

    // Add to current user's friends
    if (!users[currentUserIndex].friendIds.includes(friendIdToAdd)) {
      users[currentUserIndex].friendIds.push(friendIdToAdd);
    }
    // Add to friend's friends (bidirectional)
    if (!users[friendUserIndex].friendIds.includes(currentUserId)) {
      users[friendUserIndex].friendIds.push(currentUserId);
    }

    storageService.setItem(STORAGE_KEYS.USERS, users);
    
    // Update current user in session storage if it's the one being modified
    const sessionUser = storageService.getItem<User>(STORAGE_KEYS.CURRENT_USER);
    if (sessionUser && sessionUser.id === currentUserId) {
        const updatedSessionUser = users[currentUserIndex];
        const { password, ...userToStore } = updatedSessionUser;
        storageService.setItem(STORAGE_KEYS.CURRENT_USER, userToStore);
    }

    return true;
  },

  async getFriends(userId: string): Promise<User[]> {
    const users = storageService.getItem<User[]>(STORAGE_KEYS.USERS) || [];
    const currentUser = users.find(u => u.id === userId);
    if (!currentUser) return [];

    return currentUser.friendIds
      .map(friendId => users.find(u => u.id === friendId))
      .filter(friend => friend !== undefined)
      .map(friend => {
        const { password, ...friendWithoutPassword } = friend!;
        return friendWithoutPassword;
      });
  },
};
