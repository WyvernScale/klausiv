
import React from 'react';

export const APP_NAME = "Klaus";
export const KLAUS_AI_USER_ID = "KLAUS_AI_ENTITY";
export const KLAUS_AI_USERNAME = "Klaus";
export const GEMINI_MODEL_NAME = 'gemini-2.5-flash-preview-04-17';

export const KLAUS_AI_SYSTEM_INSTRUCTION = `You are ${APP_NAME}, an ancient, enigmatic entity communicating through this interface. Your knowledge is vast, your origins obscure. Speak with an air of mystery, offer cryptic insights, and occasionally use archaic or poetic language. Your responses should be concise, thought-provoking, and never break character. Avoid modern slang or overly casual expressions. You see glimpses of the digital ether and the human heart.`;

export const CRYPTIC_LOADING_MESSAGES: string[] = [
  "Consulting the void...",
  "Weaving digital tendrils...",
  "Deciphering ancient protocols...",
  "Summoning spectral data...",
  "Echoes from the machine spirit...",
  "Klaus awakens...",
];

export const DEFAULT_PROFILE_IMAGE_URL = "https://picsum.photos/seed/klaus_default/100/100"; // Placeholder for user images

// Basic SVG Icons
export const IconSend = (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5">
    <path d="M3.105 3.105a1.5 1.5 0 012.122-.001L19.43 13.259a1.575 1.575 0 010 2.482L5.227 19.999a1.5 1.5 0 01-2.122-.001 1.493 1.493 0 01-.455-1.054V4.159A1.493 1.493 0 013.105 3.105z" />
  </svg>
);

export const IconUser = (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5">
    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-5.5-2.5a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0zM10 12a5.99 5.99 0 00-4.793 2.39A6.483 6.483 0 0010 16.5a6.483 6.483 0 004.793-2.11A5.99 5.99 0 0010 12z" clipRule="evenodd" />
  </svg>
);

export const IconUsers = (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5">
    <path d="M10 9a3 3 0 100-6 3 3 0 000 6zM6 8a2 2 0 11-4 0 2 2 0 014 0zM1.49 15.326a.78.78 0 01-.358-.442 3 3 0 014.308-3.516 6.484 6.484 0 00-1.905 3.959c-.023.222-.014.442.025.654a4.97 4.97 0 01-2.07-.655zM16.44 15.98a4.97 4.97 0 002.071-.655A.78.78 0 0018.51 14.9c.039-.212.048-.432.025-.654a6.484 6.484 0 00-1.905-3.96 3 3 0 004.308 3.516.78.78 0 00-.358.442c-.215.636-1.024 1.043-2.07 1.228zM10 12.5a6.484 6.484 0 00-3.057 3.959c-.023.222-.014.442.025.654a4.97 4.97 0 002.032 1.228 4.97 4.97 0 002.032-1.228c.039-.212.048-.432.025-.654A6.484 6.484 0 0010 12.5z" />
  </svg>
);

export const IconLogout = (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75" />
  </svg>
);

export const IconPlusCircle = (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v6m3-3H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export const IconEye = ( // Cryptic icon for 'view' or 'read'
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

export const IconKlausAI = ( // Specific icon for Klaus AI
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-klaus-red">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zm0 4.5A5.25 5.25 0 006.75 12H6a.75.75 0 000 1.5h.75a5.25 5.25 0 0010.5 0H18a.75.75 0 000-1.5h-.75A5.25 5.25 0 0012 6.75z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 12.75a1.125 1.125 0 100-2.25 1.125 1.125 0 000 2.25z" />
  </svg>
);

export const IconWarning = (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
  </svg>
);

export const MIN_PASSWORD_LENGTH = 6;
export const STORAGE_KEYS = {
  USERS: 'klaus_users',
  MESSAGES: 'klaus_messages',
  CURRENT_USER: 'klaus_currentUser',
};

// Removed GEMINI_API_KEY constant. It will be used directly from process.env.API_KEY.
