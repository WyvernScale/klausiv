
import React, { useState, useEffect, useCallback } from 'react';
import Sidebar from './Sidebar';
import ChatWindow from './ChatWindow';
import { useAuth } from '../contexts/AuthContext';
import { KLAUS_AI_USER_ID, KLAUS_AI_USERNAME, IconKlausAI } from '../constants';
import { userService } from '../services/userService';
import { messageService } from '../services/messageService';
import { User, Message, Chat } from '../types';

const ChatPage: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);
  const [chats, setChats] = useState<Chat[]>([]);
  const [isLoadingChats, setIsLoadingChats] = useState(true);
  
  const fetchChats = useCallback(async () => {
    if (!currentUser) return;
    setIsLoadingChats(true);
    try {
      const userChats = await messageService.getChatList(currentUser.id);
      setChats(userChats);
      // If no chat is selected, or selected chat is no longer valid, select Klaus AI or first chat
      if (!selectedChat && userChats.length > 0) {
        const klausAIChat = userChats.find(c => c.id === KLAUS_AI_USER_ID);
        setSelectedChat(klausAIChat || userChats[0]);
      } else if (selectedChat && !userChats.find(c => c.id === selectedChat.id)) {
         const klausAIChat = userChats.find(c => c.id === KLAUS_AI_USER_ID);
         setSelectedChat(klausAIChat || (userChats.length > 0 ? userChats[0] : null) );
      }
    } catch (error) {
      console.error("Error fetching chats:", error);
      // Handle error display if necessary
    } finally {
      setIsLoadingChats(false);
    }
  }, [currentUser, selectedChat]);


  useEffect(() => {
    fetchChats();
  }, [fetchChats]);
  
  const handleSelectChat = (chat: Chat) => {
    setSelectedChat(chat);
  };

  const handleNewMessage = useCallback(async (message: Message) => {
    // This function is called when a new message is sent/received for the *selected* chat
    // It should refresh the chat list to update last message and order
    await fetchChats(); // Re-fetch chats to update order and last messages

    // If the new message belongs to the currently selected chat, ChatWindow will update itself.
    // If it belongs to another chat, the sidebar will reflect the new last message.
  }, [fetchChats]);

  const handleFriendAdded = useCallback(async () => {
    await fetchChats(); // Re-fetch chats when a friend is added
  }, [fetchChats]);


  if (!currentUser) return null; // Should be handled by router, but good practice

  return (
    <div className="flex h-screen antialiased text-klaus-text bg-klaus-deep-dark">
      <Sidebar
        currentUser={currentUser}
        chats={chats}
        selectedChat={selectedChat}
        onSelectChat={handleSelectChat}
        onLogout={logout}
        isLoading={isLoadingChats}
        onFriendAdded={handleFriendAdded}
        refreshChats={fetchChats}
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        {selectedChat ? (
          <ChatWindow
            key={selectedChat.id} // Force re-render when chat changes
            chat={selectedChat}
            currentUser={currentUser}
            onNewMessage={handleNewMessage}
          />
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-10 text-center bg-klaus-dark">
            {IconKlausAI}
            <p className="mt-4 text-xl font-serif text-klaus-text-secondary">
              Select a conduit to begin communication.
            </p>
            <p className="mt-2 text-sm text-klaus-text-secondary/70">
              Or perhaps, seek out new entities in the 'Discover' tab.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatPage;
