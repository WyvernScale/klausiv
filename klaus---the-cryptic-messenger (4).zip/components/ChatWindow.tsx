
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { User, Message, Chat, ChatHistoryPart } from '../types';
import { messageService } from '../services/messageService';
import { geminiService } from '../services/geminiService';
import { KLAUS_AI_USER_ID, IconSend, IconKlausAI, KLAUS_AI_USERNAME, IconWarning } from '../constants';
import LoadingSpinner from './LoadingSpinner';
import MessageBubble from './MessageBubble';

interface ChatWindowProps {
  chat: Chat;
  currentUser: User;
  onNewMessage: (message: Message) => void; // Callback to inform parent about new messages
}

const ChatWindow: React.FC<ChatWindowProps> = ({ chat, currentUser, onNewMessage }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessageContent, setNewMessageContent] = useState('');
  const [isLoadingMessages, setIsLoadingMessages] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const isKlausAIChat = chat.id === KLAUS_AI_USER_ID;

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const fetchMessages = useCallback(async () => {
    setIsLoadingMessages(true);
    setError(null);
    try {
      const fetchedMessages = await messageService.getMessages(currentUser.id, chat.id);
      setMessages(fetchedMessages);
    } catch (err) {
      console.error("Error fetching messages:", err);
      setError("Failed to conjure messages from the ether.");
    } finally {
      setIsLoadingMessages(false);
    }
  }, [currentUser.id, chat.id]);

  useEffect(() => {
    fetchMessages();
  }, [fetchMessages]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!newMessageContent.trim()) return;
    setIsSending(true);
    setError(null);

    try {
      const sentMessage = await messageService.sendMessage(currentUser.id, chat.id, newMessageContent.trim());
      setMessages(prev => [...prev, sentMessage]);
      onNewMessage(sentMessage); // Notify parent
      setNewMessageContent('');

      if (isKlausAIChat) {
        if (!geminiService.isConfigured()) {
          const aiErrorMsgText = "Klaus's connection is severed (AI interface not configured). The void is silent.";
          const aiErrorMsg = await messageService.sendMessage(KLAUS_AI_USER_ID, currentUser.id, aiErrorMsgText, true);
          setMessages(prev => [...prev, aiErrorMsg]);
          onNewMessage(aiErrorMsg);
          setIsSending(false);
          setError("Klaus AI is not configured. Please check API Key setup."); // User-facing error
          return;
        }
        
        // Construct history for Klaus AI. For chat.sendMessage, the instance maintains history.
        // Passing explicit history here might be redundant if relying on instance memory,
        // or necessary if we wanted to control context more finely per call.
        // The current setup with geminiService.getKlausAIChatResponse relies on the chat instance's memory.
        const chatHistoryForGemini: ChatHistoryPart[] = messages // Take recent messages
            .slice(-10) // Example: last 10 messages for context window
            .filter(m => m.senderId === currentUser.id || m.senderId === KLAUS_AI_USER_ID) 
            .map(m => ({
                role: m.senderId === currentUser.id ? "user" : "model",
                parts: [{ text: m.content }]
            }));
        // Add current user message to the history being considered for this call (if not already included by `messages` state update timing)
        if (!chatHistoryForGemini.find(p => p.parts[0].text === sentMessage.content && p.role === "user")) {
             chatHistoryForGemini.push({role: "user", parts: [{text: sentMessage.content}]});
        }


        const aiResponseContent = await geminiService.getKlausAIChatResponse(sentMessage.content, chatHistoryForGemini);
        const aiResponseMessage = await messageService.sendMessage(KLAUS_AI_USER_ID, currentUser.id, aiResponseContent, true);
        setMessages(prev => [...prev, aiResponseMessage]);
        onNewMessage(aiResponseMessage);
      }
    } catch (err: any) {
      console.error("Error sending message:", err);
      const errorMessage = err.message || "Your whisper was lost in the static.";
      setError(errorMessage);
      // Optionally, add a message to the chat indicating failure
      const systemErrorMsg = `System: Failed to send message. ${errorMessage}`;
      try {
        const errorNotification = await messageService.sendMessage(KLAUS_AI_USER_ID, currentUser.id, systemErrorMsg, true); // Send as AI for visibility
        setMessages(prev => [...prev, errorNotification]);
        onNewMessage(errorNotification);
      } catch (notificationError) {
        console.error("Failed to send error notification message:", notificationError);
      }
    } finally {
      setIsSending(false);
      scrollToBottom();
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-klaus-dark">
      {/* Chat Header */}
      <header className="bg-klaus-deep-dark p-4 text-klaus-text border-b border-klaus-border flex items-center space-x-3">
        {isKlausAIChat ? (
          IconKlausAI
        ) : (
          <img src={`https://picsum.photos/seed/${chat.id}/40/40`} alt={chat.name} className="w-10 h-10 rounded-full border-2 border-klaus-border object-cover" />
        )}
        <div>
          <h2 className={`text-lg font-semibold ${isKlausAIChat ? 'font-serif text-klaus-red' : ''}`}>{chat.name}</h2>
          <p className="text-xs text-klaus-text-secondary italic">
            {isKlausAIChat ? "Ancient Entity" : "Connected"}
          </p>
        </div>
      </header>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-thin scrollbar-thumb-klaus-red scrollbar-track-klaus-deep-dark">
        {isLoadingMessages && <LoadingSpinner message="Summoning past whispers..."/>}
        {!isLoadingMessages && messages.length === 0 && (
           <div className="text-center text-klaus-text-secondary italic py-10">
            <p>{isKlausAIChat ? `The air is still. Speak to ${KLAUS_AI_USERNAME}, and perhaps the void will answer.` : `No whispers exchanged with ${chat.name} yet. Be the first to break the silence.`}</p>
          </div>
        )}
        {!isLoadingMessages && messages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} isSender={msg.senderId === currentUser.id} />
        ))}
        <div ref={messagesEndRef} />
      </div>
      
      {/* Error Display */}
      {error && (
        <div className="p-3 bg-red-900/70 text-red-200 text-sm border-t border-klaus-border flex items-center space-x-2">
          <span className="text-klaus-light-red">{IconWarning}</span>
          <span>Error: {error}</span>
        </div>
      )}
      {isKlausAIChat && !geminiService.isConfigured() && (
         <div className="p-3 bg-yellow-900/70 text-yellow-200 text-sm border-t border-klaus-border flex items-center space-x-2">
          <span className="text-yellow-400">{IconWarning}</span>
          <span>Klaus AI is dormant. The necessary API configuration is missing or invalid.</span>
        </div>
      )}


      {/* Message Input */}
      <footer className="bg-klaus-deep-dark p-4 border-t border-klaus-border">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center space-x-3"
        >
          <input
            type="text"
            value={newMessageContent}
            onChange={(e) => setNewMessageContent(e.target.value)}
            placeholder={isKlausAIChat ? `Whisper to ${KLAUS_AI_USERNAME}...` : `Message ${chat.name}...`}
            className="flex-1 px-4 py-2 bg-klaus-dark border border-klaus-border rounded-full text-klaus-text focus:outline-none focus:ring-2 focus:ring-klaus-red focus:border-klaus-red placeholder-klaus-text-secondary/70"
            disabled={isSending || (isKlausAIChat && !geminiService.isConfigured())}
            aria-label={isKlausAIChat ? `Whisper to ${KLAUS_AI_USERNAME}` : `Message ${chat.name}`}
          />
          <button
            type="submit"
            disabled={isSending || !newMessageContent.trim() || (isKlausAIChat && !geminiService.isConfigured())}
            className="p-3 rounded-full bg-klaus-red text-klaus-text hover:bg-klaus-light-red focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-klaus-deep-dark focus:ring-klaus-light-red disabled:opacity-50 transition-colors"
            aria-label="Send message"
          >
            {isSending ? <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" role="status" aria-live="polite"><span className="sr-only">Sending...</span></div> : IconSend}
          </button>
        </form>
      </footer>
    </div>
  );
};

export default ChatWindow;
