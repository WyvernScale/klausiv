
import React, { useState, useEffect } from 'react';
import { CRYPTIC_LOADING_MESSAGES } from '../constants';

interface LoadingSpinnerProps {
  message?: string;
  size?: 'sm' | 'md' | 'lg';
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ message, size = 'md' }) => {
  const [currentMessage, setCurrentMessage] = useState(
    message || CRYPTIC_LOADING_MESSAGES[Math.floor(Math.random() * CRYPTIC_LOADING_MESSAGES.length)]
  );

  useEffect(() => {
    if (!message) {
      const intervalId = setInterval(() => {
        setCurrentMessage(CRYPTIC_LOADING_MESSAGES[Math.floor(Math.random() * CRYPTIC_LOADING_MESSAGES.length)]);
      }, 3000);
      return () => clearInterval(intervalId);
    } else {
        setCurrentMessage(message);
    }
  }, [message]);

  const sizeClasses = {
    sm: 'w-8 h-8 border-2',
    md: 'w-12 h-12 border-4',
    lg: 'w-16 h-16 border-4',
  };

  return (
    <div className="flex flex-col items-center justify-center space-y-4">
      <div 
        className={`animate-spin rounded-full ${sizeClasses[size]} border-klaus-red border-t-transparent`}
        style={{ borderTopColor: 'transparent' }} // Ensure Tailwind JIT picks this up or be explicit
      ></div>
      <p className="text-klaus-text-secondary font-serif text-sm italic">{currentMessage}</p>
    </div>
  );
};

export default LoadingSpinner;
