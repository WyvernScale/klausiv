
import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { APP_NAME, MIN_PASSWORD_LENGTH, IconWarning } from '../constants';
import LoadingSpinner from './LoadingSpinner';

const AuthPage: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { login, signup } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!username.trim() || !password.trim()) {
      setError("Username and password must not be hollow.");
      return;
    }
    if (!isLogin && password.length < MIN_PASSWORD_LENGTH) {
      setError(`Your pact (password) must be at least ${MIN_PASSWORD_LENGTH} characters strong.`);
      return;
    }
    
    setIsLoading(true);
    try {
      if (isLogin) {
        await login(username, password);
      } else {
        await signup(username, password);
      }
      navigate('/chat');
    } catch (err: any) {
      setError(err.message || "An unknown shadow falls upon your attempt.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-klaus-deep-dark p-4">
      <div className="w-full max-w-md bg-klaus-dark shadow-xl shadow-klaus-red/30 rounded-lg p-8 border border-klaus-border">
        <h1 className="text-4xl font-serif text-klaus-red text-center mb-2">{APP_NAME}</h1>
        <p className="text-klaus-text-secondary text-center mb-8 font-serif italic">
          {isLogin ? "Whisper your name to enter the fold." : "Forge a new identity in the shadows."}
        </p>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-klaus-text-secondary font-serif">
              Identity (Username)
            </label>
            <input
              id="username"
              name="username"
              type="text"
              autoComplete="username"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="mt-1 block w-full px-3 py-2 bg-klaus-deep-dark border border-klaus-border rounded-md text-klaus-text shadow-sm focus:outline-none focus:ring-klaus-red focus:border-klaus-red sm:text-sm"
              placeholder="e.g., ShadowSeeker"
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-klaus-text-secondary font-serif">
              Secret Word (Password)
            </label>
            <input
              id="password"
              name="password"
              type="password"
              autoComplete={isLogin ? "current-password" : "new-password"}
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 block w-full px-3 py-2 bg-klaus-deep-dark border border-klaus-border rounded-md text-klaus-text shadow-sm focus:outline-none focus:ring-klaus-red focus:border-klaus-red sm:text-sm"
              placeholder="Enter your secret"
            />
          </div>

          {error && (
            <div className="bg-red-900/50 border border-klaus-red text-red-300 px-4 py-3 rounded-md text-sm flex items-center space-x-2">
              <div className="text-klaus-light-red">{IconWarning}</div>
              <p>{error}</p>
            </div>
          )}

          <div>
            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-klaus-text bg-klaus-red hover:bg-klaus-light-red focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-klaus-dark focus:ring-klaus-light-red disabled:opacity-50 transition-colors duration-150"
            >
              {isLoading ? <LoadingSpinner size="sm" message={isLogin ? "Verifying identity..." : "Forging pact..."}/> : (isLogin ? "Enter the Circle" : "Seal the Pact")}
            </button>
          </div>
        </form>

        <p className="mt-8 text-center text-sm text-klaus-text-secondary">
          {isLogin ? "New to these whispers?" : "Already bound?"}{' '}
          <button
            onClick={() => { setIsLogin(!isLogin); setError(null); }}
            className="font-medium text-klaus-light-red hover:text-klaus-red focus:outline-none underline"
          >
            {isLogin ? "Carve your name." : "Recall your vow."}
          </button>
        </p>
      </div>
      <footer className="mt-12 text-center text-xs text-klaus-text-secondary font-serif">
        <p>&copy; {new Date().getFullYear()} {APP_NAME}. All secrets veiled.</p>
        <p className="mt-1 italic">Data is stored locally. The void remembers only what your browser allows.</p>
      </footer>
    </div>
  );
};

export default AuthPage;
