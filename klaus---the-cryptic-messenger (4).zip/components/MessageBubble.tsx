
import React from 'react';
import { Message } from '../types';
import { KLAUS_AI_USER_ID } from '../constants';

interface MessageBubbleProps {
  message: Message;
  isSender: boolean;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message, isSender }) => {
  const isAIMessage = message.senderId === KLAUS_AI_USER_ID;

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const bubbleClasses = isSender
    ? 'bg-klaus-red text-white rounded-br-none'
    : isAIMessage
    ? 'bg-transparent border border-klaus-red text-klaus-text rounded-bl-none shadow-md shadow-klaus-red/20'
    : 'bg-klaus-deep-dark text-klaus-text rounded-bl-none border border-klaus-border';
  
  const alignmentClasses = isSender ? 'ml-auto' : 'mr-auto';

  return (
    <div className={`flex ${isSender ? 'justify-end' : 'justify-start'} mb-1`}>
      <div className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-3 rounded-xl shadow ${bubbleClasses} ${alignmentClasses}`}>
        {isAIMessage && !isSender && (
            <p className="text-xs font-serif text-klaus-light-red mb-1">Klaus whispers:</p>
        )}
        <p className={`text-sm whitespace-pre-wrap break-words ${isAIMessage ? 'italic font-serif' : ''}`}>
          {message.content}
        </p>
        <p className={`text-xs mt-1 ${isSender ? 'text-red-200/80 text-right' : isAIMessage ? 'text-klaus-red/80 text-left' : 'text-klaus-text-secondary/80 text-left'}`}>
          {formatTimestamp(message.timestamp)}
        </p>
      </div>
    </div>
  );
};

export default MessageBubble;
