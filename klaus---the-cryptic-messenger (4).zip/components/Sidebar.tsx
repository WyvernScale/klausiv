
import React, { useState, useEffect, useCallback } from 'react';
import { User, Chat } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { KLAUS_AI_USER_ID, KLAUS_AI_USERNAME, IconLogout, IconUsers, IconPlusCircle, IconKlausAI, DEFAULT_PROFILE_IMAGE_URL } from '../constants';
import { userService } from '../services/userService';
import LoadingSpinner from './LoadingSpinner';

interface SidebarProps {
  currentUser: User;
  chats: Chat[];
  selectedChat: Chat | null;
  onSelectChat: (chat: Chat) => void;
  onLogout: () => void;
  isLoading: boolean;
  onFriendAdded: () => void;
  refreshChats: () => void;
}

type ActiveTab = 'chats' | 'discover';

const Sidebar: React.FC<SidebarProps> = ({
  currentUser,
  chats,
  selectedChat,
  onSelectChat,
  onLogout,
  isLoading,
  onFriendAdded,
  refreshChats
}) => {
  const [discoverUsers, setDiscoverUsers] = useState<User[]>([]);
  const [isLoadingDiscover, setIsLoadingDiscover] = useState(false);
  const [activeTab, setActiveTab] = useState<ActiveTab>('chats');
  const { updateCurrentUserFriends } = useAuth();

  const fetchDiscoverUsers = useCallback(async () => {
    if (activeTab !== 'discover') return;
    setIsLoadingDiscover(true);
    try {
      const allUsers = await userService.getAllUsers(currentUser.id);
      const friends = await userService.getFriends(currentUser.id);
      const friendIds = friends.map(f => f.id);
      setDiscoverUsers(allUsers.filter(u => !friendIds.includes(u.id) && u.id !== KLAUS_AI_USER_ID));
    } catch (error) {
      console.error("Error fetching discoverable users:", error);
    } finally {
      setIsLoadingDiscover(false);
    }
  }, [currentUser.id, activeTab, currentUser.friendIds]); // Added currentUser.friendIds

  useEffect(() => {
    if (activeTab === 'discover') {
      fetchDiscoverUsers();
    }
  }, [activeTab, fetchDiscoverUsers]);

  const handleAddFriend = async (friendId: string) => {
    try {
      await userService.addFriend(currentUser.id, friendId);
      updateCurrentUserFriends(friendId, 'add'); // Update context
      await fetchDiscoverUsers(); // Refresh discover list
      await onFriendAdded(); // Refresh chat list in parent
      // Optionally switch to chats tab or select the new friend
    } catch (error) {
      console.error("Error adding friend:", error);
    }
  };
  
  const getChatDisplayTime = (timestamp?: string) => {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    }
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };


  const SidebarItem: React.FC<{ chat: Chat; isSelected: boolean; onClick: () => void }> = ({ chat, isSelected, onClick }) => (
    <li
      onClick={onClick}
      className={`flex items-center p-3 space-x-3 cursor-pointer hover:bg-klaus-dark/50 transition-colors duration-150 rounded-md ${
        isSelected ? 'bg-klaus-red/30' : ''
      }`}
    >
      {chat.id === KLAUS_AI_USER_ID ? (
         IconKlausAI
      ) : (
        <img 
          src={`https://picsum.photos/seed/${chat.id}/40/40`} // Unique placeholder image
          alt={chat.name} 
          className="w-10 h-10 rounded-full border-2 border-klaus-border object-cover" 
        />
      )}
      <div className="flex-1 min-w-0">
        <h3 className={`font-medium truncate ${chat.id === KLAUS_AI_USER_ID ? 'font-serif text-klaus-light-red' : 'text-klaus-text'}`}>
          {chat.name}
        </h3>
        {chat.lastMessage && (
          <p className="text-xs text-klaus-text-secondary truncate">
            {chat.lastMessage.senderId === currentUser.id ? "You: " : ""}
            {chat.lastMessage.content}
          </p>
        )}
         {!chat.lastMessage && chat.type === 'user' && (
          <p className="text-xs text-klaus-text-secondary/70 italic truncate">No whispers shared yet.</p>
        )}
      </div>
      {chat.lastMessage && (
        <span className="text-xs text-klaus-text-secondary/70 self-start pt-1">
          {getChatDisplayTime(chat.lastMessage.timestamp)}
        </span>
      )}
    </li>
  );
  
  return (
    <div className="w-80 flex flex-col border-r border-klaus-border bg-klaus-dark">
      {/* Header */}
      <div className="p-4 border-b border-klaus-border flex items-center justify-between">
        <div className="flex items-center space-x-2">
           <img src={`https://picsum.photos/seed/${currentUser.id}/40/40`} alt={currentUser.username} className="w-10 h-10 rounded-full border-2 border-klaus-red object-cover" />
           <div>
            <h2 className="text-lg font-semibold font-serif text-klaus-text">{currentUser.username}</h2>
            <p className="text-xs text-klaus-text-secondary italic">Online in the Echoes</p>
           </div>
        </div>
        <button
          onClick={onLogout}
          title="Sever Connection"
          className="p-2 rounded-md text-klaus-text-secondary hover:text-klaus-red hover:bg-klaus-deep-dark/50 transition-colors"
        >
          {IconLogout}
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-klaus-border">
        <button
          onClick={() => setActiveTab('chats')}
          className={`flex-1 py-3 text-sm font-medium font-serif transition-colors ${
            activeTab === 'chats' ? 'text-klaus-red border-b-2 border-klaus-red bg-klaus-deep-dark/30' : 'text-klaus-text-secondary hover:text-klaus-text'
          }`}
        >
          Conduits (Chats)
        </button>
        <button
          onClick={() => setActiveTab('discover')}
          className={`flex-1 py-3 text-sm font-medium font-serif transition-colors ${
            activeTab === 'discover' ? 'text-klaus-red border-b-2 border-klaus-red bg-klaus-deep-dark/30' : 'text-klaus-text-secondary hover:text-klaus-text'
          }`}
        >
          Seek Entities (Discover)
        </button>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2 scrollbar-thin scrollbar-thumb-klaus-red scrollbar-track-klaus-deep-dark">
        {activeTab === 'chats' && (
          <>
            {isLoading && <LoadingSpinner message="Tuning frequencies..." />}
            {!isLoading && chats.length === 0 && (
              <p className="text-center text-klaus-text-secondary italic py-4">
                No active conduits. Seek entities or await whispers.
              </p>
            )}
            {!isLoading && chats.length > 0 && (
              <ul className="space-y-1">
                {chats.map((chat) => (
                  <SidebarItem 
                    key={chat.id} 
                    chat={chat} 
                    isSelected={selectedChat?.id === chat.id} 
                    onClick={() => onSelectChat(chat)} 
                  />
                ))}
              </ul>
            )}
          </>
        )}

        {activeTab === 'discover' && (
          <>
            {isLoadingDiscover && <LoadingSpinner message="Scanning the aether..." />}
            {!isLoadingDiscover && discoverUsers.length === 0 && (
              <p className="text-center text-klaus-text-secondary italic py-4">
                No new entities found in this plane.
              </p>
            )}
            {!isLoadingDiscover && discoverUsers.length > 0 && (
              <ul className="space-y-2">
                {discoverUsers.map((user) => (
                  <li key={user.id} className="flex items-center p-3 space-x-3 bg-klaus-deep-dark/30 rounded-md border border-klaus-border/50">
                     <img src={`https://picsum.photos/seed/${user.id}/40/40`} alt={user.username} className="w-10 h-10 rounded-full border-2 border-klaus-border object-cover" />
                    <div className="flex-1">
                      <h3 className="font-medium text-klaus-text">{user.username}</h3>
                      <p className="text-xs text-klaus-text-secondary italic">Joined: {new Date(user.createdAt).toLocaleDateString()}</p>
                    </div>
                    <button
                      onClick={() => handleAddFriend(user.id)}
                      title={`Form bond with ${user.username}`}
                      className="p-2 rounded-full text-klaus-text-secondary hover:text-klaus-light-red hover:bg-klaus-red/20 transition-colors"
                    >
                      {IconPlusCircle}
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
      </div>
       {/* Refresh button for chats in case something goes out of sync */}
      <div className="p-2 border-t border-klaus-border">
        <button
          onClick={refreshChats}
          className="w-full text-xs text-klaus-text-secondary hover:text-klaus-red py-2 rounded hover:bg-klaus-deep-dark/50 transition-colors"
        >
          Refresh Conduits
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
